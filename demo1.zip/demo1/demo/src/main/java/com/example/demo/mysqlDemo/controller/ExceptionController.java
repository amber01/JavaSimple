package com.example.demo.mysqlDemo.controller;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/**
 * @ Author     ：tank
 * @ Date       ：Created in 11:52 2018/8/25
 * @ Description：全局捕获异常处理
 * @ Modified By：
 * @Version:
 */
//@ControllerAdvice
public class ExceptionController {

//    @ExceptionHandler
//    public void test(){
//        System.out.print("操作失败了");
//    }
}
